﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Vue_WebApi.Models
{
    public class NorthwindContext : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public NorthwindContext() : base("name=NorthwindContext")
        {
        }

        public System.Data.Entity.DbSet<Vue_WebApi.Models.Customer> Customers { get; set; }
    
    }
}
